# SLCB-WebhookDiscordMessage
Mostly and example script for Streamlabs Chatbot testing sending messages to a discord webhook instead of using the built in discord message method included in streamlabs.
